/*
Sara Paulina González Lucero        21111194
Edgar Allan Velasquez Polanco       21111102
*/
package ComponentesU2;

import java.awt.Component;
import java.awt.Dimension;
import javax.swing.JScrollPane;

public class ScrollPane extends JScrollPane{
    
    public ScrollPane(Component a){
        this.setPreferredSize(new Dimension(1198,598));
        this.setViewportView(a);
        this.setVerticalScrollBarPolicy(this.VERTICAL_SCROLLBAR_ALWAYS);
        this.setHorizontalScrollBarPolicy(this.HORIZONTAL_SCROLLBAR_NEVER);
    }
    
}
