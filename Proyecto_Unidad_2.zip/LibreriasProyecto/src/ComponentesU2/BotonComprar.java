/*
Sara Paulina González Lucero        21111194
Edgar Allan Velasquez Polanco       21111102
*/
package ComponentesU2;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import javax.swing.JButton;

public class BotonComprar extends JButton{
    
    public BotonComprar(){
        this.setPreferredSize(new Dimension(85,85));
        this.setBackground(new Color(26,41,56));
        this.setBorder(null);
        this.setForeground(new Color(141,227,17));
        this.setFont(new Font("Gill Sans MT", Font.BOLD,18));
    }
    
}
