/*
Edgar Allan Velasquez Polanco           21111102
Sara Paulina González Lucero            21111194
*/
package proyecto;

import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

public class PanelPrincipal extends JFrame implements ActionListener, MouseListener {

    Container contenedor;
    JPanel panelPrincipal, panelSuperior, panelCentral, panelInferior;
    JButton productos, empleados;
    JLabel tituloNegocio, iconoManual, usuarioInfo, fiotoTienda, fotoUsuario, version;
    InicioSesion us = new InicioSesion("", "");

    public PanelPrincipal() {
        contenedor = this.getContentPane();

        panelPrincipal = new JPanel();
        panelPrincipal.setPreferredSize(new Dimension(648, 698));
        panelPrincipal.setLayout(new FlowLayout(FlowLayout.CENTER, 50, 15));

        panelSuperior = new JPanel();
        panelSuperior.setPreferredSize(new Dimension(620, 100));
        panelSuperior.setBackground(Color.RED);
        panelSuperior.setLayout(new FlowLayout(FlowLayout.CENTER, 0, 25));

        ImageIcon usuariofoto = new ImageIcon("C:\\Users\\valla\\OneDrive\\Documentos\\NetBeansProjects\\ProyectoU4\\src\\proyecto\\Imagenes\\usuario.png");
        Image img3 = usuariofoto.getImage();
        Image nuevaImagen3 = img3.getScaledInstance(25, 25, java.awt.Image.SCALE_SMOOTH);
        usuariofoto = new ImageIcon(nuevaImagen3);
        fotoUsuario = new JLabel(usuariofoto);
        fotoUsuario.setPreferredSize(new Dimension(50, 25));
        fotoUsuario.addMouseListener(this);

        usuarioInfo = new JLabel(us.getUsuario());
        usuarioInfo.setPreferredSize(new Dimension(100, 35));
        usuarioInfo.setForeground(Color.white);
        usuarioInfo.setFont(new Font("Arial", Font.PLAIN, 18));

        ImageIcon manual = new ImageIcon("C:\\Users\\valla\\OneDrive\\Documentos\\NetBeansProjects\\ProyectoU4\\src\\proyecto\\Imagenes\\manual.png");
        Image img1 = manual.getImage();
        Image nuevaImagen1 = img1.getScaledInstance(25, 25, java.awt.Image.SCALE_SMOOTH);
        manual = new ImageIcon(nuevaImagen1);
        iconoManual = new JLabel(manual);
        iconoManual.setPreferredSize(new Dimension(50, 25));
        iconoManual.addMouseListener(this);

        ImageIcon manual2 = new ImageIcon("C:\\Users\\valla\\OneDrive\\Documentos\\NetBeansProjects\\ProyectoU4\\src\\proyecto\\Imagenes\\version.png");
        Image img4 = manual2.getImage();
        Image nuevaImagen4 = img4.getScaledInstance(25, 25, java.awt.Image.SCALE_SMOOTH);
        manual2 = new ImageIcon(nuevaImagen4);
        version = new JLabel(manual2);
        version.setPreferredSize(new Dimension(50, 25));
        version.addMouseListener(this);

        tituloNegocio = new JLabel("Abarrotes *Doña Lupe* ", SwingConstants.CENTER);
        tituloNegocio.setForeground(Color.white);
        tituloNegocio.setPreferredSize(new Dimension(300, 50));
        tituloNegocio.setFont(new Font("Arial Narrow", Font.BOLD, 30));

        panelCentral = new JPanel();
        panelCentral.setPreferredSize(new Dimension(450, 270));

        panelCentral.setLayout(new FlowLayout(FlowLayout.CENTER, 2, 20));

        ImageIcon ImagenClinica = new ImageIcon("C:\\Users\\valla\\OneDrive\\Documentos\\NetBeansProjects\\ProyectoU4\\src\\proyecto\\Imagenes\\tienda.png");
        Image img5 = ImagenClinica.getImage();
        Image nuevaImagen5 = img5.getScaledInstance(300, 250, java.awt.Image.SCALE_SMOOTH);
        ImagenClinica = new ImageIcon(nuevaImagen5);
        fiotoTienda = new JLabel(ImagenClinica);

        fiotoTienda.setPreferredSize(new Dimension(448, 250));

        panelInferior = new JPanel();
        panelInferior.setPreferredSize(new Dimension(620, 100));
        panelInferior.setLayout(new FlowLayout(FlowLayout.CENTER, 5, 25));

        productos = new JButton("Productos");
        productos.setPreferredSize(new Dimension(150, 50));
        productos.setFont(new Font("Arial Narrow", Font.BOLD, 18));
        productos.setForeground(Color.WHITE);
        productos.setBackground(Color.RED);
        productos.addActionListener(this);

        empleados = new JButton("Empleados");
        empleados.setPreferredSize(new Dimension(150, 50));
        empleados.setFont(new Font("Arial Narrow", Font.BOLD, 18));
        empleados.setForeground(Color.WHITE);
        empleados.setBackground(Color.RED);
        empleados.addActionListener(this);

        contenedor.add(panelPrincipal);
        panelPrincipal.add(panelSuperior);
        panelSuperior.add(fotoUsuario);
        panelSuperior.add(usuarioInfo);
        panelSuperior.add(tituloNegocio);
        panelSuperior.add(iconoManual);
        panelSuperior.add(version);

        panelPrincipal.add(panelCentral);
        panelCentral.add(fiotoTienda);
        panelPrincipal.add(panelInferior);
        panelInferior.add(productos);
        panelInferior.add(empleados);
        ImageIcon iconoVentana = new ImageIcon("C:\\Users\\valla\\OneDrive\\Documentos\\NetBeansProjects\\ProyectoU4\\src\\proyecto\\Imagenes\\tienda.png");
        Image img8 = iconoVentana.getImage();
        this.setIconImage(img8);
        this.setSize(650, 575);
        this.setVisible(true);
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    public static void main(String[] args) {
        new PanelPrincipal();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == productos) {
            Productos p = new Productos();
            p.setVisible(true);
            this.dispose();
        }
        if (e.getSource() == empleados) {
            Empleados obj1 = new Empleados();
            obj1.setVisible(true);
            this.dispose();
        }

    }

    @Override
    public void mouseClicked(MouseEvent ae) {
        if (ae.getSource() == fotoUsuario) {
            InicioSesion a = new InicioSesion(true);
            a.dispose();
            this.dispose();
        }
        if (ae.getSource() == iconoManual) {
            try {
                String url = "C:\\Users\\valla\\OneDrive\\Documentos\\NetBeansProjects\\ProyectoU4\\src\\proyecto\\Imagenes\\Manual-de-usuario.pdf";
                ProcessBuilder p = new ProcessBuilder();
                p.command("cmd.exe", "/c", url);
                p.start();

            } catch (Exception evvv) {
                JOptionPane.showMessageDialog(null, "No se puede abrir el archivo de ayuda, probablemente fue borrado", "ERROR", JOptionPane.ERROR_MESSAGE);

            }
        }
        if (ae.getSource() == version) {
            JOptionPane.showMessageDialog(null, "2.0 3000",
                    "Version", JOptionPane.WARNING_MESSAGE);
        }
    }

    @Override
    public void mousePressed(MouseEvent e) {
    }

    @Override
    public void mouseReleased(MouseEvent e) {
    }

    @Override
    public void mouseEntered(MouseEvent e) {
    }

    @Override
    public void mouseExited(MouseEvent e) {
    }

}
