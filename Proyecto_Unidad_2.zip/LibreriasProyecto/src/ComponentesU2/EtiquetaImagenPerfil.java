/*
Sara Paulina González Lucero        21111194
Edgar Allan Velasquez Polanco       21111102
*/
package ComponentesU2;

import java.awt.Color;
import java.awt.Dimension;
import javax.swing.ImageIcon;
import javax.swing.JLabel;

public class EtiquetaImagenPerfil extends JLabel{
    
    public EtiquetaImagenPerfil(ImageIcon imagen){
        
        this.setIcon(imagen);
        this.setPreferredSize(new Dimension(120,55));
        this.setBackground(new Color(26, 41, 56));
        this.setOpaque(true);
        
    }
    
}
