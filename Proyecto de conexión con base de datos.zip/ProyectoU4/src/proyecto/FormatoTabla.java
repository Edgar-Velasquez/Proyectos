/*
Edgar Allan Velasquez Polanco           21111102
Sara Paulina González Lucero            21111194
 */
package proyecto;

import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import javax.swing.JLabel;
import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;

public class FormatoTabla extends DefaultTableCellRenderer {

    public Component getTableCellRendererComponent(JTable tabla,
            Object valor, boolean isSelected, boolean hasFocus, int fila, int columna) {
        JLabel celda = (JLabel) super.getTableCellRendererComponent(tabla, valor, isSelected, hasFocus, fila, columna);

        celda.setHorizontalAlignment(celda.CENTER);

        if (tabla.getRowCount() % 2 == 0) {
            celda.setBackground(Color.WHITE);
        } else {

        }

        if (isSelected) {
            celda.setBackground(Color.white);
        }
        if (hasFocus) {
            celda.setBackground(Color.gray);
        } 
        
        return celda;
    }

    public FormatoTabla() {
    }

}
