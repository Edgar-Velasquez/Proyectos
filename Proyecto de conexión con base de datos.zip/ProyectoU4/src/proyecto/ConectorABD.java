/*
Edgar Allan Velasquez Polanco           21111102
Sara Paulina González Lucero            21111194
*/
package proyecto;

import com.mysql.jdbc.Connection;
import java.sql.DriverManager;

public class ConectorABD {
    
    private String direccion = "jdbc:mysql://localhost:3306/tienda";
    private String usuario = "EDGAR";
    private String password = "contra1234";
    
    public ConectorABD(String usuario, String contra){
        this.setUsuario(usuario);
        this.setPassword(contra);
    }
    
    public ConectorABD(){
        
    }
    
    public Connection metodoConectar(){
        Connection conexion = null;
        try{
            Class.forName("com.mysql.jdbc.Driver");
            conexion = (Connection) DriverManager.getConnection(direccion,usuario,password);
        }catch(Exception e){
        }
        return conexion;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
    
       
    
}
