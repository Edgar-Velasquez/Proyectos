/*
Sara Paulina González Lucero        21111194
Edgar Allan Velasquez Polanco       21111102
*/
package ComponentesU2;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import javax.swing.JLabel;

public class EtiquetaTexto extends JLabel {

    public EtiquetaTexto() {
        this.setPreferredSize(new Dimension(755, 85));
        this.setOpaque(true);
        this.setBackground(new Color(26, 41, 56));
        this.setForeground(new Color(255, 255, 241));
        this.setFont(new Font("Calibir", Font.PLAIN, 18));
    }
}
