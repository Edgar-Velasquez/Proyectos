/*
Edgar Allan Velasquez Polanco           21111102
Sara Paulina González Lucero            21111194
 */
package proyecto;

import com.mysql.jdbc.Connection;
import java.awt.*;
import java.awt.event.*;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import com.mysql.jdbc.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.SwingConstants;

public class Productos extends JFrame implements ActionListener, MouseListener {

    Container contenedor;
    JPanel panelPrincipal, subpanelDatos, panelEtiqueta,
            panelDerecho, panelCampoInsertar, panelDatos;
    JLabel etiqueta1, etiquetaNombre, etiquetaCant, etiquetaPrecio, fotoUsuario, usuarioInfo, iconoSalir;
    JTextField campoTexto1, campoTexto2, campoTexto3;
    JButton insertar, borrar, actualizar;
    InicioSesion iniciar = new InicioSesion("", "");
    String nombreTabla = "productos";
    JLabel[] arregloEtiquetas;
    JTextField[] arregloCampos;
    ResultSetMetaData esmt;
    boolean banderaDeBorrado = true;
    String llavePrimaria = "";
    Connection variableConexion;
    ConectorABD varC;
    JTable tablaSelect;
    DefaultTableModel modeloTabla = new DefaultTableModel();
    JScrollPane panelTabla;

    public Productos() {
        contenedor = this.getContentPane();

        panelPrincipal = new JPanel();
        panelPrincipal.setPreferredSize(new Dimension(1200, 600));
        panelPrincipal.setLayout(new FlowLayout(FlowLayout.CENTER, 0, 0));

        panelDatos = new JPanel();
        panelDatos.setPreferredSize(new Dimension(600, 598));

        subpanelDatos = new JPanel();
        subpanelDatos.setPreferredSize(new Dimension(600, 598));
        subpanelDatos.setBackground(Color.WHITE);
        subpanelDatos.setLayout(new FlowLayout(FlowLayout.CENTER, 50, 10));

        panelDerecho = new JPanel();
        panelDerecho.setPreferredSize(new Dimension(598, 598));

        etiquetaNombre = new JLabel("Nombre: ", SwingConstants.CENTER);
        etiquetaNombre.setBackground(new Color(28, 145, 63));
        etiquetaNombre.setForeground(Color.black);
        etiquetaNombre.setFont(new Font("New times Roman", Font.BOLD, 20));
        etiquetaNombre.setPreferredSize(new Dimension(120, 30));

        campoTexto1 = new JTextField();
        campoTexto1.setFont(new Font("Times New Roman", Font.PLAIN, 20));
        campoTexto1.setPreferredSize(new Dimension(400, 25));

        etiquetaCant = new JLabel("Cantidad: ", SwingConstants.CENTER);
        etiquetaCant.setBackground(new Color(28, 145, 63));
        etiquetaCant.setForeground(Color.black);
        etiquetaCant.setFont(new Font("New times Roman", Font.BOLD, 20));
        etiquetaCant.setPreferredSize(new Dimension(120, 30));

        campoTexto2 = new JTextField();
        campoTexto2.setFont(new Font("Times New Roman", Font.PLAIN, 20));
        campoTexto2.setPreferredSize(new Dimension(400, 25));

        etiquetaPrecio = new JLabel("Precio", SwingConstants.CENTER);
        etiquetaPrecio.setBackground(new Color(28, 145, 63));
        etiquetaPrecio.setForeground(Color.black);
        etiquetaPrecio.setFont(new Font("New times Roman", Font.BOLD, 20));
        etiquetaPrecio.setPreferredSize(new Dimension(120, 30));

        campoTexto3 = new JTextField();
        campoTexto3.setFont(new Font("Times New Roman", Font.PLAIN, 20));
        campoTexto3.setPreferredSize(new Dimension(400, 25));

        insertar = new JButton("Insertar");
        insertar.setPreferredSize(new Dimension(120, 40));
        insertar.setFont(new Font("New times Roman", Font.BOLD, 15));
        insertar.setBackground(Color.RED);
        insertar.setForeground(Color.white);
        insertar.addActionListener(this);

        borrar = new JButton("Borrar");
        borrar.setPreferredSize(new Dimension(120, 40));
        borrar.setFont(new Font("New times Roman", Font.BOLD, 15));
        borrar.setBackground(Color.RED);
        borrar.setForeground(Color.white);
        borrar.addActionListener(this);

        actualizar = new JButton("Actualizar");
        actualizar.setPreferredSize(new Dimension(120, 40));
        actualizar.setFont(new Font("New times Roman", Font.BOLD, 15));
        actualizar.setBackground(Color.RED);
        actualizar.setForeground(Color.white);
        actualizar.addActionListener(this);

        subpanelDatos.add(etiquetaNombre);
        subpanelDatos.add(campoTexto1);
        subpanelDatos.add(etiquetaCant);
        subpanelDatos.add(campoTexto2);
        subpanelDatos.add(etiquetaPrecio);
        subpanelDatos.add(campoTexto3);

        subpanelDatos.add(insertar);
        subpanelDatos.add(borrar);
        subpanelDatos.add(actualizar);

        ImageIcon usuariofoto = new ImageIcon("C:\\Users\\valla\\OneDrive\\Documentos\\NetBeansProjects\\ProyectoU4\\src\\proyecto\\Imagenes\\usuario.png");
        Image img3 = usuariofoto.getImage();
        Image nuevaImagen3 = img3.getScaledInstance(25, 25, java.awt.Image.SCALE_SMOOTH);
        usuariofoto = new ImageIcon(nuevaImagen3);
        fotoUsuario = new JLabel(usuariofoto);
        fotoUsuario.setPreferredSize(new Dimension(50, 25));
        fotoUsuario.addMouseListener(this);

        usuarioInfo = new JLabel(iniciar.getUsuario());
        usuarioInfo.setPreferredSize(new Dimension(55, 35));
        usuarioInfo.setForeground(Color.white);
        usuarioInfo.setFont(new Font("Arial", Font.PLAIN, 15));

        ImageIcon exit = new ImageIcon("C:\\Users\\valla\\OneDrive\\Documentos\\NetBeansProjects\\ProyectoU4\\src\\proyecto\\Imagenes\\salir.png");
        Image img1 = exit.getImage();
        Image nuevaImagen1 = img1.getScaledInstance(25, 25, java.awt.Image.SCALE_SMOOTH);
        exit = new ImageIcon(nuevaImagen1);
        iconoSalir = new JLabel(exit);
        iconoSalir.setPreferredSize(new Dimension(50, 25));
        iconoSalir.addMouseListener(this);

        panelEtiqueta = new JPanel();
        panelEtiqueta.setPreferredSize(new Dimension(598, 80));
        panelEtiqueta.setBackground(Color.RED);
        etiqueta1 = new JLabel("Productos", SwingConstants.CENTER);
        etiqueta1.setBackground(Color.RED);
        etiqueta1.setOpaque(true);
        etiqueta1.setForeground(Color.WHITE);
        etiqueta1.setFont(new Font("Berlin Sans FB Demi", Font.BOLD, 50));
        etiqueta1.setPreferredSize(new Dimension(400, 80));

        panelEtiqueta.add(fotoUsuario);
        panelEtiqueta.add(usuarioInfo);
        panelEtiqueta.add(etiqueta1);
        panelEtiqueta.add(iconoSalir);

        tablaSelect = new JTable();

        panelTabla = new JScrollPane(tablaSelect, panelTabla.VERTICAL_SCROLLBAR_AS_NEEDED, panelTabla.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        panelTabla.setPreferredSize(new Dimension(598, 598));
        //   panelTabla.setBorder(BorderFactory.createLineBorder(Color.black));
        panelTabla.setBackground(Color.DARK_GRAY);

        panelCampoInsertar = new JPanel();
        panelCampoInsertar.setPreferredSize(new Dimension(598, 400));
        panelCampoInsertar.setLayout(new FlowLayout(FlowLayout.CENTER, 0, 0));
        //     panelCampoInsertar.setBorder(BorderFactory.createLineBorder(Color.black));

        panelDerecho.add(panelTabla);
        panelDerecho.add(panelCampoInsertar);
        panelDatos.add(panelEtiqueta);
        panelDatos.add(subpanelDatos);

        panelPrincipal.add(panelDatos);
        panelPrincipal.add(panelDerecho);
        contenedor.add(panelPrincipal);

        ImageIcon iconoVentana = new ImageIcon("C:\\Users\\valla\\OneDrive\\Documentos\\NetBeansProjects\\ProyectoU4\\src\\proyecto\\Imagenes\\producto.png");
        Image img8 = iconoVentana.getImage();

        varC = new ConectorABD();
        variableConexion = varC.metodoConectar();
        if (banderaDeBorrado == false) {
            eliminarCamposYEtiquetasResgistros();
        } else {
            banderaDeBorrado = false;
        }
        limpiarModeloTabla();
        obtenerComunasTblas();
        selectRegistro();
        disenoTabla();
        pintarCamposYEttiquetasParaRegistro();

        this.setSize(1220, 600);
        this.setResizable(false);
        this.setIconImage(img8);
        this.setLocationRelativeTo(null);
        this.setVisible(true);
        this.setTitle("Menú Principal");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

    }

    public static void main(String[] args) {
        new Productos();
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        if (e.getSource() == borrar) {
            eliminarRegistro();
        }
        if (e.getSource() == insertar) {
            insertarDatos();
            limpiarCamposRegistro();
        }

        if (e.getSource() == actualizar) {
            if (tablaSelect.isEditing()) {
                tablaSelect.getCellEditor().stopCellEditing();
            }
            actualizarRegistro();
        }

    }

    public void limpiarCampos() {
        campoTexto1.setText("");
        campoTexto2.setText("");
        campoTexto3.setText("");

        campoTexto1.requestFocus();

    }

    public void eliminarCamposYEtiquetasResgistros() {
        for (int j = 0; j < modeloTabla.getColumnCount(); j++) {
            panelCampoInsertar.remove(arregloEtiquetas[j]);
            panelCampoInsertar.remove(arregloCampos[j]);
        }
        panelCampoInsertar.paintAll(panelCampoInsertar.getGraphics());
    }

    public void limpiarModeloTabla() {
        modeloTabla.setColumnCount(0);
        for (int i = modeloTabla.getRowCount(); i > 0; i--) {
            modeloTabla.removeRow(i - 1);
        }
    }

    public void obtenerComunasTblas() {
        ResultSet resultadoColumnas;
        com.mysql.jdbc.PreparedStatement prepararConsultaColumnasAuto, prepararConsultasColumnas,
                prepararConusltasColumnasID;
        try {
            prepararConsultaColumnasAuto = (com.mysql.jdbc.PreparedStatement) variableConexion.prepareStatement("select COLUMN_NAME FROM"
                    + " information_schema. COLUMNS where TABLE_NAME='"
                    + nombreTabla + "'"
                    + " and EXTRA='auto_increment';");
            resultadoColumnas = prepararConsultaColumnasAuto.executeQuery();
            while (resultadoColumnas.next()) {
                modeloTabla.addColumn(resultadoColumnas.getString("COLUMN_NAME") + "(auto)");
            }
            prepararConusltasColumnasID = (com.mysql.jdbc.PreparedStatement) variableConexion.prepareStatement("select COLUMN_NAME FROM"
                    + " information_schema. KEY_COLUMN_USAGE COLUMNS where TABLE_NAME='"
                    + nombreTabla + "'"
                    + ";");
            resultadoColumnas = prepararConusltasColumnasID.executeQuery();
            while (resultadoColumnas.next()) {
                llavePrimaria = resultadoColumnas.getString("COLUMN_NAME") + "";
            }
            prepararConsultasColumnas = (com.mysql.jdbc.PreparedStatement) variableConexion.prepareStatement("select COLUMN_NAME FROM"
                    + " information_schema. COLUMNS where TABLE_NAME='"
                    + nombreTabla + "'"
                    + " and EXTRA!='auto_increment';");
            resultadoColumnas = prepararConsultasColumnas.executeQuery();
            while (resultadoColumnas.next()) {
                modeloTabla.addColumn(resultadoColumnas.getString("COLUMN_NAME"));
            }

        } catch (Exception ex) {
            System.out.println("error: " + ex);
            JOptionPane.showMessageDialog(null, "Se ha dado un error" + ex);
        }
    }

    public void selectRegistro() {
        PreparedStatement prepararConsulta;
        ResultSet resultadoConsulta;
        try {
            String camposParaSelect = "";
            for (int j = 0; j < modeloTabla.getColumnCount(); j++) {
                if (modeloTabla.getColumnName(j).length() > 6) {
                    if (!modeloTabla.getColumnName(j).substring(
                            modeloTabla.getColumnName(j).length() - 6,
                            modeloTabla.getColumnName(j).length()).toString().equals("(auto)")) {
                        camposParaSelect += modeloTabla.getColumnName(j) + ", ";
                    } else {
                        camposParaSelect += modeloTabla.getColumnName(j).substring(
                                0, modeloTabla.getColumnName(j).length() - 6) + ", ";
                    }
                } else {
                    camposParaSelect += modeloTabla.getColumnName(j) + ", ";
                }
            }
            camposParaSelect = camposParaSelect.substring(0,
                    camposParaSelect.length() - 2);

            prepararConsulta = (com.mysql.jdbc.PreparedStatement) variableConexion.prepareStatement("select " + camposParaSelect + " from " + nombreTabla + ";");
            resultadoConsulta = prepararConsulta.executeQuery();
            esmt = resultadoConsulta.getMetaData();
            String[] vectores = new String[esmt.getColumnCount()];
            while (resultadoConsulta.next()) {
                for (int i = 0; i < vectores.length; i++) {
                    vectores[i] = "" + resultadoConsulta.getString(i + 1);
                }
                modeloTabla.addRow(vectores);
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Se ha producido el siguente error " + ex);
        }
    }

    public void disenoTabla() {

        tablaSelect.setModel(modeloTabla);
        tablaSelect.getTableHeader().setBackground(new Color(229, 8, 8));
        tablaSelect.getTableHeader().setForeground(Color.white);
        tablaSelect.getTableHeader().setFont(new Font("Arial", Font.BOLD, 18));
        tablaSelect.setDefaultRenderer(Object.class, new FormatoTabla());

    }

    public void pintarCamposYEttiquetasParaRegistro() {
        arregloEtiquetas = new JLabel[modeloTabla.getColumnCount()];
        arregloCampos = new JTextField[modeloTabla.getColumnCount()];
        for (int j = 0; j < modeloTabla.getColumnCount(); j++) {
            arregloEtiquetas[j] = new JLabel(modeloTabla.getColumnName(j));
            arregloEtiquetas[j].setHorizontalAlignment(JLabel.RIGHT);
            arregloCampos[j] = new JTextField();
            arregloCampos[j].setPreferredSize(new Dimension(125, 35));
            arregloCampos[j].setBorder(BorderFactory.createLineBorder(new Color(77, 141, 199)));
            arregloCampos[j].setName(modeloTabla.getColumnName(j));
            if (arregloCampos[j].getName().length() >= 6) {
                if (arregloCampos[j].getName()
                        .substring(arregloCampos[j].getName().length()).equals("(auto)")) {
                    arregloCampos[j].setEnabled(false);
                    arregloCampos[j].setBackground(new Color(230, 230, 230));

                }
            }
            panelCampoInsertar.add(arregloEtiquetas[j]);
            panelCampoInsertar.add(arregloCampos[j]);

        }
        panelCampoInsertar.paintAll(panelCampoInsertar.getGraphics());
    }

    public void eliminarRegistro() {
        try {
            if (tablaSelect.getRowCount() > 0) {
                if (tablaSelect.getSelectedRow() >= 0) {
                    com.mysql.jdbc.PreparedStatement prepararConsulta;
                    String valorRegistroBorrar = "";
                    for (int i = 0; i < modeloTabla.getColumnCount(); i++) {
                        if (modeloTabla.getColumnName(i).length() > 6) {
                            if (modeloTabla.getColumnName(i).substring(
                                    0, modeloTabla.getColumnName(i).length() - 6).equals(
                                    llavePrimaria)) {
                                valorRegistroBorrar = "" + modeloTabla.getValueAt(
                                        tablaSelect.getSelectedRow(), modeloTabla.findColumn(
                                        modeloTabla.getColumnName(i)));
                            }
                        } else {
                            if (modeloTabla.getColumnName(i).equals(
                                    llavePrimaria)) {
                                valorRegistroBorrar = "" + modeloTabla.getValueAt(
                                        tablaSelect.getSelectedRow(), modeloTabla.findColumn(
                                        modeloTabla.getColumnName(i)));
                            }
                        }
                    }
                    JOptionPane.showMessageDialog(null, "Se borro el elemento: " + valorRegistroBorrar);
                    prepararConsulta
                            = (com.mysql.jdbc.PreparedStatement) variableConexion.prepareStatement("delete from"
                                    + " " + nombreTabla
                                    + " where " + llavePrimaria + "= '"
                                    + valorRegistroBorrar + "';"
                            );
                    prepararConsulta.execute();
                    modeloTabla.removeRow(tablaSelect.getSelectedRow());
                } else {
                    JOptionPane.showMessageDialog(null, "No se ha seleccionado ningun elemento");
                }

            } else {
                JOptionPane.showMessageDialog(null, "No hay elementos en la tabla actualmente");
            }

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Se ha producido el siguiente error: " + ex);
        }
    }

    public void insertarDatos() {
        try {
            com.mysql.jdbc.PreparedStatement prepararConsulta;
            prepararConsulta = (PreparedStatement) variableConexion.prepareStatement(
                    "insert into " + nombreTabla + " (" + stringCamposParaInsert() + ") values"
                    + "('" + campoTexto1.getText() + "','" + campoTexto2.getText() + "','"
                    + campoTexto3.getText() + "')  ");

            prepararConsulta.execute();
            PreparedStatement prepararConsultaID;
            ResultSet resultadoID;
            prepararConsultaID = (PreparedStatement) variableConexion.prepareStatement("SELECT max(ID) as 'idfinal' from "
                    + nombreTabla + ";");
            resultadoID = prepararConsultaID.executeQuery();
            String vector[] = new String[modeloTabla.getColumnCount()];
            if (resultadoID.next()) {
                for (int i = 0; i < arregloCampos.length; i++) {
                    if (arregloCampos[i].getName().length() > 6) {
                        if (arregloCampos[i].getName().substring(arregloCampos[i].getName().length() - 6,
                                arregloCampos[i].getName().length()).equals("(auto)")) {
                            vector[i] = arregloCampos[i].getText();
                        } else {
                            vector[i] = resultadoID.getString("idfinal") + "";
                        }
                    } else {
                        vector[i] = arregloCampos[i].getText();
                    }
                }
                varC = new ConectorABD();
                variableConexion = varC.metodoConectar();
                if (banderaDeBorrado == false) {
                    eliminarCamposYEtiquetasResgistros();
                } else {
                    banderaDeBorrado = false;
                }
                limpiarModeloTabla();
                obtenerComunasTblas();
                selectRegistro();
                disenoTabla();
                pintarCamposYEttiquetasParaRegistro();
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error al insertar datos " + e);
        }
    }

    public String stringCamposParaInsert() {
        String campos = "";
        for (int j = 0; j < modeloTabla.getColumnCount(); j++) {
            if (modeloTabla.getColumnName(j).length() > 6) {
                if (!modeloTabla.getColumnName(j).substring(
                        modeloTabla.getColumnName(j).length() - 6,
                        modeloTabla.getColumnName(j).length()).toString().equals("(auto)")) {
                    campos += modeloTabla.getColumnName(j) + ", ";
                }
            } else {
                campos += modeloTabla.getColumnName(j) + ", ";
            }
        }
        campos = campos.substring(0, campos.length() - 2);
        return campos;
    }

    public String stringValoresParaInsert() {
        String valores = "";
        for (int j = 0; j < arregloCampos.length; j++) {
            if (arregloCampos[j].getName().length() > 6) {
                if (!arregloCampos[j].getName().substring(
                        arregloCampos[j].getName().length() - 6,
                        arregloCampos[j].getName().length()).toString().equals("(auto)")) {
                    valores += "'" + arregloCampos[j].getText() + "', ";
                }
            } else {
                valores += "'" + arregloCampos[j].getText() + "', ";
            }
        }
        valores = valores.substring(0, valores.length() - 2);

        return valores;
    }

    public void limpiarCamposRegistro() {
        for (int i = 0; i < arregloCampos.length; i++) {
            arregloCampos[i].setText("");
        }
    }

    public void actualizarRegistro() {
        try {
            if (tablaSelect.getRowCount() > 0) {
                if (tablaSelect.getSelectedRow() >= 0) {

                    com.mysql.jdbc.PreparedStatement prepararConsulta;
                    String valorRegistroActualizar = "", variableUpgradeCampos = "";
                    for (int i = 0; i < modeloTabla.getColumnCount(); i++) {
                        if (modeloTabla.getColumnName(i).length() > 6) {

                            if (modeloTabla.getColumnName(i).substring(
                                    0, modeloTabla.getColumnName(i).length() - 6).equals(
                                    llavePrimaria)) {
                                valorRegistroActualizar = "" + modeloTabla.getValueAt(
                                        tablaSelect.getSelectedRow(), modeloTabla.findColumn(
                                        modeloTabla.getColumnName(i)));
                            } else if (modeloTabla.getColumnName(i).equals(
                                    llavePrimaria)) {
                                valorRegistroActualizar = "" + modeloTabla.getValueAt(
                                        tablaSelect.getSelectedRow(), modeloTabla.findColumn(
                                        modeloTabla.getColumnName(i)));
                            }
                        } else {
                            if (modeloTabla.getColumnName(i).equals(
                                    llavePrimaria)) {
                                valorRegistroActualizar = "" + modeloTabla.getValueAt(
                                        tablaSelect.getSelectedRow(), modeloTabla.findColumn(
                                        modeloTabla.getColumnName(i)));
                            }
                        }
                    }
                    for (int i = 0; i < modeloTabla.getColumnCount(); i++) {
                        if (modeloTabla.getColumnName(i).length() > 6) {

                            if (!modeloTabla.getColumnName(i).substring(
                                    modeloTabla.getColumnName(i).length() - 6, modeloTabla.getColumnName(i).length()).
                                    equals("(auto)")) {
                                variableUpgradeCampos += modeloTabla.getColumnName(i)
                                        + "='" + modeloTabla.getValueAt(tablaSelect.getSelectedRow(), modeloTabla.findColumn(modeloTabla.getColumnName(i))) + "', ";
                            } else {
                                variableUpgradeCampos += modeloTabla.getColumnName(i).substring(0, modeloTabla.getColumnName(i).length() - 6)
                                        + "='" + modeloTabla.getValueAt(tablaSelect.getSelectedRow(), modeloTabla.findColumn(modeloTabla.getColumnName(i))) + "', ";
                            }
                        } else {
                            variableUpgradeCampos += modeloTabla.getColumnName(i)
                                    + "='" + modeloTabla.getValueAt(tablaSelect.getSelectedRow(), modeloTabla.findColumn(modeloTabla.getColumnName(i))) + "', ";
                        }
                    }
                    variableUpgradeCampos = variableUpgradeCampos.substring(0, variableUpgradeCampos.length() - 2);
                    prepararConsulta
                            = (com.mysql.jdbc.PreparedStatement) variableConexion.prepareStatement(
                                    "update " + nombreTabla + " set "
                                    + variableUpgradeCampos
                                    + " where " + llavePrimaria + "= '"
                                    + valorRegistroActualizar + "';"
                            );

                    prepararConsulta.execute();
                    JOptionPane.showMessageDialog(null, "Se actualizo el registro: " + valorRegistroActualizar);
                } else {
                    JOptionPane.showMessageDialog(null, "No se ha seleccionado ningun elemento");
                }
            } else {
                JOptionPane.showMessageDialog(null, "No hay elementos en la tabla actualmente");
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error al actualizar elementos: " + e);
        }
    }

    @Override
    public void mouseClicked(MouseEvent e) {
        if (e.getSource() == fotoUsuario) {
            InicioSesion a = new InicioSesion(true);
            a.dispose();
            this.dispose();
        }
        if (e.getSource() == iconoSalir) {
            PanelPrincipal pa = new PanelPrincipal();
            pa.setVisible(true);
            this.dispose();
        }
    }

    @Override
    public void mousePressed(MouseEvent e) {

    }

    @Override
    public void mouseReleased(MouseEvent e) {

    }

    @Override
    public void mouseEntered(MouseEvent e) {

    }

    @Override
    public void mouseExited(MouseEvent e) {

    }

}
