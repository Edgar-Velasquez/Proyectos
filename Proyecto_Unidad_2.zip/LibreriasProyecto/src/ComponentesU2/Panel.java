/*
Sara Paulina González Lucero        21111194
Edgar Allan Velasquez Polanco       21111102
*/
package ComponentesU2;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import javax.swing.JPanel;

public class Panel extends JPanel{
    
    public Panel(){
        this.setPreferredSize(new Dimension(1198,598));
        this.setBackground(new Color(27,44,67));
        this.setLayout(new FlowLayout(FlowLayout.CENTER, 0,15));
    }
    
}
