/*
Edgar Allan Velasquez Polanco           21111102
Sara Paulina González Lucero            21111194
*/
package proyecto;

import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

public class InicioSesion extends JFrame implements ActionListener, MouseListener {

    private String usuario = "EDGAR";
    private String contrasena = "contra1234";
    Container contenedor;
    JPanel panelPrincipal, panelInicio;
    JLabel iconoUsuario, iniciarLabel;
    JPasswordField campoTextoContrasena;
    JButton enter;

    public InicioSesion() {

        contenedor = this.getContentPane();
        panelPrincipal = new JPanel();
        panelPrincipal.setPreferredSize(new Dimension(648, 698));
        panelPrincipal.setBackground(Color.LIGHT_GRAY);
        panelPrincipal.setLayout(new FlowLayout(FlowLayout.CENTER, 0, 100));

        panelInicio = new JPanel();
        panelInicio.setPreferredSize(new Dimension(300, 450));
        panelInicio.setBackground(Color.GRAY);
        panelInicio.setLayout(new FlowLayout(FlowLayout.CENTER, 0, 25));

        ImageIcon usuario = new ImageIcon("C:\\Users\\valla\\OneDrive\\Documentos\\NetBeansProjects\\ProyectoU4\\src\\proyecto\\Imagenes\\usuario2.png");
        Image img1 = usuario.getImage();
        Image nuevaImagen1 = img1.getScaledInstance(150, 150, java.awt.Image.SCALE_SMOOTH);
        usuario = new ImageIcon(nuevaImagen1);
        iconoUsuario = new JLabel(usuario);
        iconoUsuario.setPreferredSize(new Dimension(300, 150));

        iniciarLabel = new JLabel(this.getUsuario());
        iniciarLabel.setForeground(Color.white);
        iniciarLabel.setPreferredSize(new Dimension(60, 30));
        iniciarLabel.setFont(new Font("Arial", Font.BOLD, 15));
        iniciarLabel.setVerticalAlignment(SwingConstants.CENTER);

        campoTextoContrasena = new JPasswordField();
        campoTextoContrasena.setPreferredSize(new Dimension(250, 35));
        TextPrompt textoContra = new TextPrompt("Contraseña:", campoTextoContrasena);
        textoContra.setForeground(Color.LIGHT_GRAY);

        enter = new JButton("Iniciar Sesion");
        enter.setPreferredSize(new Dimension(135, 40));
        enter.setBackground(new Color(0, 128, 192));
        enter.setForeground(Color.WHITE);
        enter.addActionListener(this);

        contenedor.add(panelPrincipal);
        panelPrincipal.add(panelInicio);
        panelInicio.add(iconoUsuario);
        panelInicio.add(iniciarLabel);
        panelInicio.add(campoTextoContrasena);
        panelInicio.add(enter);
        ImageIcon iconoVentana = new ImageIcon("C:\\Users\\valla\\OneDrive\\Documentos\\NetBeansProjects\\ProyectoU4\\src\\proyecto\\Imagenes\\usuario2.png");
        Image img8 = iconoVentana.getImage();
        this.setIconImage(img8);
        this.setSize(650, 700);
        this.setVisible(true);
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setTitle("Iniciar Sesion");
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getContrasena() {
        return contrasena;
    }

    public void setContrasena(String contrasena) {
        this.contrasena = contrasena;
    }

    public InicioSesion(String usuario, String Contrasena) {
    }
    
    public InicioSesion(boolean cambio){
        this.dispose();
        new cambioUsuario();
    }
    
    public void cambiarContra(String contra){
        setContrasena(contra);
    }

    public static void main(String[] args) {
        new InicioSesion();
    }

    @Override
    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == enter) {
            ConectorABD conector = new ConectorABD(usuario, campoTextoContrasena.getText());
            if (conector.metodoConectar() == null) {
                JOptionPane.showMessageDialog(null, "Usuario o contrasena incorrectos");
                campoTextoContrasena.setText("");
                campoTextoContrasena.requestFocus();
            } else {
                try {
                    this.setContrasena(campoTextoContrasena.getText());
                    JOptionPane.showMessageDialog(null, "Ingresando Sesion...");
                    Thread.sleep(500);
                } catch (InterruptedException ex) {
                    Logger.getLogger(InicioSesion.class.getName()).log(Level.SEVERE, null, ex);
                }

                PanelPrincipal p = new PanelPrincipal();
                p.setVisible(true);
                this.dispose();
            }
        }
    }

    public void mouseClicked(MouseEvent e) {
    }

    @Override
    public void mousePressed(MouseEvent e) {

    }

    @Override
    public void mouseReleased(MouseEvent e) {

    }

    @Override
    public void mouseEntered(MouseEvent e) {

    }

    @Override
    public void mouseExited(MouseEvent e) {

    }

    public class cambioUsuario extends JFrame implements ActionListener, MouseListener {

        Container contenedor;
        JPanel panelPrincipal, panelInicio;
        JLabel iconoUsuario, nUsuario, contraA, nContra, cContra;
        JTextField campoTextoUsuario;
        JPasswordField campoTextoContrasenaActual, campoTextoContrasenaCambio, campoTextoContrasenaConfirma;
        JButton cambiar, cancelar;

        public cambioUsuario() {
            contenedor = this.getContentPane();
            panelPrincipal = new JPanel();
            panelPrincipal.setPreferredSize(new Dimension(648, 698));
            panelPrincipal.setBackground(Color.LIGHT_GRAY);
            panelPrincipal.setLayout(new FlowLayout(FlowLayout.CENTER, 0, 100));

            panelInicio = new JPanel();
            panelInicio.setPreferredSize(new Dimension(300, 525));
            panelInicio.setBackground(Color.GRAY);
            panelInicio.setLayout(new FlowLayout(FlowLayout.CENTER, 10, 5));

            ImageIcon icono = new ImageIcon("C:\\Users\\valla\\OneDrive\\Documentos\\NetBeansProjects\\ProyectoU4\\src\\proyecto\\Imagenes\\usuario.png");
            icono = new ImageIcon(icono.getImage().getScaledInstance(150, 150, java.awt.Image.SCALE_SMOOTH));
            iconoUsuario = new JLabel(icono);
            iconoUsuario.setPreferredSize(new Dimension(300, 175));

            nUsuario = new JLabel("Usuario", SwingConstants.CENTER);
            nUsuario.setPreferredSize(new Dimension(150, 25));
            nUsuario.setForeground(Color.WHITE);
            contraA = new JLabel("Contraseña Actual", SwingConstants.CENTER);
            contraA.setPreferredSize(new Dimension(150, 25));
            contraA.setForeground(Color.WHITE);
            nContra = new JLabel("Nueva contraseña", SwingConstants.CENTER);
            nContra.setPreferredSize(new Dimension(150, 25));
            nContra.setForeground(Color.WHITE);
            cContra = new JLabel("Confirmar contraseña", SwingConstants.CENTER);
            cContra.setPreferredSize(new Dimension(150, 25));
            cContra.setForeground(Color.WHITE);

            campoTextoUsuario = new JTextField( );
            campoTextoUsuario.setPreferredSize(new Dimension(250, 35));
            campoTextoUsuario.addMouseListener(this);
            campoTextoContrasenaActual = new JPasswordField();
            campoTextoContrasenaActual.setPreferredSize(new Dimension(250, 35));
            campoTextoContrasenaCambio = new JPasswordField();
            campoTextoContrasenaCambio.setPreferredSize(new Dimension(250, 35));
            campoTextoContrasenaConfirma = new JPasswordField();
            campoTextoContrasenaConfirma.setPreferredSize(new Dimension(250, 35));

            cambiar = new JButton("Cambiar");
            cambiar.setPreferredSize(new Dimension(100, 40));
            cambiar.setBackground(new Color(0, 128, 192));
            cambiar.setForeground(Color.WHITE);
            cambiar.addActionListener(this);

            cancelar = new JButton("Cancelar");
            cancelar.setPreferredSize(new Dimension(100, 40));
            cancelar.setBackground(new Color(0, 128, 192));
            cancelar.setForeground(Color.WHITE);
            cancelar.addActionListener(this);

            contenedor.add(panelPrincipal);
            panelPrincipal.add(panelInicio);
            panelInicio.add(iconoUsuario);
            panelInicio.add(nUsuario);
            panelInicio.add(campoTextoUsuario);
            panelInicio.add(contraA);
            panelInicio.add(campoTextoContrasenaActual);
            panelInicio.add(nContra);
            panelInicio.add(campoTextoContrasenaCambio);
            panelInicio.add(cContra);
            panelInicio.add(campoTextoContrasenaConfirma);
            panelInicio.add(cambiar);
            panelInicio.add(cancelar);
            ImageIcon iconoVentana = new ImageIcon("C:\\Users\\HP\\Documents\\NetBeansProjects\\Proyecto\\src\\ImagenesProyecto\\usuario.png");
            this.setIconImage(iconoVentana.getImage());
            this.setSize(650, 700);
            this.setVisible(true);
            this.setLocationRelativeTo(null);
            this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        }

        @Override
        public void actionPerformed(ActionEvent ae) {
            if (ae.getSource() == cambiar) {
                InicioSesion usuario = new InicioSesion("","");
                if (campoTextoUsuario.getText().equals(usuario.getUsuario())) {
                    if (campoTextoContrasenaActual.getText().equals(usuario.getContrasena())) {
                        if (campoTextoContrasenaCambio.getText().equals(campoTextoContrasenaConfirma.getText())) {
                            setContrasena(campoTextoContrasenaConfirma.getText());
                            JOptionPane.showMessageDialog(null, "La contraseña y el usuario han sido cambiados correctamente");
                            campoTextoUsuario.setText("");
                            campoTextoContrasenaActual.setText("");
                            campoTextoContrasenaCambio.setText("");
                            campoTextoContrasenaConfirma.setText("");
                            campoTextoUsuario.requestFocus();
                            PanelPrincipal p = new PanelPrincipal();
                            p.setVisible(true);
                            this.dispose();
                        } else {
                            JOptionPane.showMessageDialog(null, "Las nuevas contraseñas no coinciden");
                            campoTextoUsuario.setText("");
                            campoTextoContrasenaActual.setText("");
                            campoTextoContrasenaCambio.setText("");
                            campoTextoContrasenaConfirma.setText("");
                            campoTextoUsuario.requestFocus();
                        }
                    } else {
                        JOptionPane.showMessageDialog(null, "Contraseña Incorrecta");
                        campoTextoUsuario.setText("");
                        campoTextoContrasenaActual.setText("");
                        campoTextoContrasenaCambio.setText("");
                        campoTextoContrasenaConfirma.setText("");
                        campoTextoUsuario.requestFocus();
                    }

                } else {
                    JOptionPane.showMessageDialog(null, "Usuario Incorrecto");
                    campoTextoUsuario.setText("");
                    campoTextoContrasenaActual.setText("");
                    campoTextoContrasenaCambio.setText("");
                    campoTextoContrasenaConfirma.setText("");
                    campoTextoUsuario.requestFocus();
                }
            }
            if (ae.getSource() == cancelar) {
                PanelPrincipal p = new PanelPrincipal();
                p.setVisible(true);
                this.dispose();
            }
        }

        public void mouseClicked(MouseEvent e) {
            if (e.getSource() == campoTextoUsuario) {
                campoTextoUsuario.setText("");
            }

        }

        @Override
        public void mousePressed(MouseEvent e) {

        }

        @Override
        public void mouseReleased(MouseEvent e) {

        }

        @Override
        public void mouseEntered(MouseEvent e) {

        }

        @Override
        public void mouseExited(MouseEvent e) {

        }
    }

}
