/*
Sara Paulina González Lucero        21111194
Edgar Allan Velasquez Polanco       21111102
 */
package Proyecto;

import ComponentesU2.*;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTabbedPane;
import javax.swing.SwingConstants;

public class Proyecto extends JFrame implements MouseListener, ActionListener {

    JTabbedPane tabulador;
    Panel tienda, perfil, subpanelPerfil, subpanelInfo;
    ScrollPane scrollTienda, scrollPerfil;
    EtiquetaImagen stardewValley, danganronpa, turnipBoy, nier, omori, uno;
    EtiquetaImagenPerfil pStardewValley, pDanganronpa, pTurnipBoy, pNier, pOmori, pUno;
    EtiquetaImagenPerfil fotoUser;
    EtiquetaTexto tStardew, tDanganronpa, tTurnipBoy, tNier, tOmori, tUno;
    EtiquetaTextoPerfil ptStardew, ptDanganronpa, ptTurnipBoy, ptNier, ptOmori, ptUno;
    EtiquetaTextoPerfil nombreUser, descUser, insignia;
    BotonComprar cStardew, cDanganronpa, cTurnipBoy, cNier, cOmori, cUno;
    String[] biblioteca = new String[6];

    public Proyecto() {

        biblioteca[0] = "Stardew";
        biblioteca[1] = "Nier";
        biblioteca[2] = "Uno";
        biblioteca[3] = "TurnipBoy";
        biblioteca[4] = "Danganropa";
        biblioteca[5] = "Omori";

        tabulador = new JTabbedPane();
        tabulador.setPreferredSize(new Dimension(1200, 600));
        tabulador.setBackground(new Color(104, 93, 101));
        tabulador.setOpaque(true);
        tabulador.setForeground(new Color(255, 228, 246));

        tienda = new Panel();
        perfil = new Panel();

        //Panel de Tienda
        ImageIcon logo = new ImageIcon("C:\\Users\\valla\\OneDrive\\Documentos\\"
                + "NetBeansProjects\\Proyecto\\src\\Proyecto\\ImagenesJuegos\\logo.png");
        Image imgL = logo.getImage().getScaledInstance(25, 25, java.awt.Image.SCALE_SMOOTH);

        ImageIcon stardew = new ImageIcon("C:\\Users\\valla\\OneDrive\\Documentos\\"
                + "NetBeansProjects\\Proyecto\\src\\Proyecto\\ImagenesJuegos\\stardewValley.png");
        stardew = new ImageIcon(stardew.getImage().getScaledInstance(185, 85, java.awt.Image.SCALE_SMOOTH));

        ImageIcon imagenD = new ImageIcon("C:\\Users\\valla\\OneDrive\\Documentos\\"
                + "NetBeansProjects\\Proyecto\\src\\Proyecto\\ImagenesJuegos\\danganronpa.png");
        imagenD = new ImageIcon(imagenD.getImage().getScaledInstance(185, 85, java.awt.Image.SCALE_SMOOTH));

        ImageIcon imagenT = new ImageIcon("C:\\Users\\valla\\OneDrive\\Documentos\\"
                + "NetBeansProjects\\Proyecto\\src\\Proyecto\\ImagenesJuegos\\turnipBoy.png");
        imagenT = new ImageIcon(imagenT.getImage().getScaledInstance(185, 85, java.awt.Image.SCALE_SMOOTH));

        ImageIcon imagenN = new ImageIcon("C:\\Users\\valla\\OneDrive\\Documentos\\"
                + "NetBeansProjects\\Proyecto\\src\\Proyecto\\ImagenesJuegos\\nier.png");
        imagenN = new ImageIcon(imagenN.getImage().getScaledInstance(185, 85, java.awt.Image.SCALE_SMOOTH));

        ImageIcon imagenO = new ImageIcon("C:\\Users\\valla\\OneDrive\\Documentos\\"
                + "NetBeansProjects\\Proyecto\\src\\Proyecto\\ImagenesJuegos\\omori.png");
        imagenO = new ImageIcon(imagenO.getImage().getScaledInstance(185, 85, java.awt.Image.SCALE_SMOOTH));

        ImageIcon imagenU = new ImageIcon("C:\\Users\\valla\\OneDrive\\Documentos\\"
                + "NetBeansProjects\\Proyecto\\src\\Proyecto\\ImagenesJuegos\\uno.png");
        imagenU = new ImageIcon(imagenU.getImage().getScaledInstance(185, 85, java.awt.Image.SCALE_SMOOTH));

        ImageIcon pStardew = new ImageIcon("C:\\Users\\valla\\OneDrive\\Documentos\\"
                + "NetBeansProjects\\Proyecto\\src\\Proyecto\\ImagenesJuegos\\StardewValley.png");
        pStardew = new ImageIcon(pStardew.getImage().getScaledInstance(100, 85, java.awt.Image.SCALE_SMOOTH));

        ImageIcon pImagenD = new ImageIcon("C:\\Users\\valla\\OneDrive\\Documentos\\"
                + "NetBeansProjects\\Proyecto\\src\\Proyecto\\ImagenesJuegos\\danganronpa.png");
        pImagenD = new ImageIcon(pImagenD.getImage().getScaledInstance(100, 85, java.awt.Image.SCALE_SMOOTH));

        ImageIcon pImagenT = new ImageIcon("C:\\Users\\valla\\OneDrive\\Documentos\\"
                + "NetBeansProjects\\Proyecto\\src\\Proyecto\\ImagenesJuegos\\turnipBoy.png");
        pImagenT = new ImageIcon(pImagenT.getImage().getScaledInstance(100, 85, java.awt.Image.SCALE_SMOOTH));

        ImageIcon pImagenN = new ImageIcon("C:\\Users\\valla\\OneDrive\\Documentos\\"
                + "NetBeansProjects\\Proyecto\\src\\Proyecto\\ImagenesJuegos\\nier.png");
        pImagenN = new ImageIcon(pImagenN.getImage().getScaledInstance(100, 85, java.awt.Image.SCALE_SMOOTH));

        ImageIcon pImagenO = new ImageIcon("C:\\Users\\valla\\OneDrive\\Documentos\\"
                + "NetBeansProjects\\Proyecto\\src\\Proyecto\\ImagenesJuegos\\omori.png");
        pImagenO = new ImageIcon(pImagenO.getImage().getScaledInstance(100, 85, java.awt.Image.SCALE_SMOOTH));

        ImageIcon pImagenU = new ImageIcon("C:\\Users\\valla\\OneDrive\\Documentos\\"
                + "NetBeansProjects\\Proyecto\\src\\Proyecto\\ImagenesJuegos\\uno.png");
        pImagenU = new ImageIcon(pImagenU.getImage().getScaledInstance(100, 85, java.awt.Image.SCALE_SMOOTH));

        stardewValley = new EtiquetaImagen(stardew);
        danganronpa = new EtiquetaImagen(imagenD);
        turnipBoy = new EtiquetaImagen(imagenT);
        nier = new EtiquetaImagen(imagenN);
        omori = new EtiquetaImagen(imagenO);
        uno = new EtiquetaImagen(imagenU);

        pStardewValley = new EtiquetaImagenPerfil(pStardew);
        pDanganronpa = new EtiquetaImagenPerfil(pImagenD);
        pTurnipBoy = new EtiquetaImagenPerfil(pImagenT);
        pNier = new EtiquetaImagenPerfil(pImagenN);
        pOmori = new EtiquetaImagenPerfil(pImagenO);
        pUno = new EtiquetaImagenPerfil(pImagenU);

        String descStardew = "<html><body> <b>Stardew Valley </b> <br> <br>"
                + "Simulador agrícola, Simulador de vida, Pixelados</body></html>";

        String descDanganronpa = "<html><body> <b>Danganronpa: Trigger Happy Havoc </b> <br> <br>"
                + "Anime, Novelas Visuales, Misterio";

        String descTurnipBoy = "<html><body> <b>TurnipBoy Commits Tax Evasion</b> <br> <br>"
                + "Indie, Aventura, Pixelados";

        String descNier = "<html><body> <b>NieR:Automata™ Game of the YoRHa Edition</b> <br> <br>"
                + "Acción, Rol, Mundo Abierto";

        String descOmori = "<html><body> <b>Omori</b> <br> <br>"
                + "Terror Psicológico, Pixelados, Indie";

        String descUno = "<html><body> <b>Uno</b> <br> <br>"
                + "Juego de cartas, Multijugador, Mesa";

        tStardew = new EtiquetaTexto();
        tStardew.setText(descStardew);
        tStardew.addMouseListener(this);
        tDanganronpa = new EtiquetaTexto();
        tDanganronpa.setText(descDanganronpa);
        tDanganronpa.addMouseListener(this);
        tTurnipBoy = new EtiquetaTexto();
        tTurnipBoy.setText(descTurnipBoy);
        tTurnipBoy.addMouseListener(this);
        tNier = new EtiquetaTexto();
        tNier.setText(descNier);
        tNier.addMouseListener(this);
        tOmori = new EtiquetaTexto();
        tOmori.setText(descOmori);
        tOmori.addMouseListener(this);
        tUno = new EtiquetaTexto();
        tUno.setText(descUno);
        tUno.addMouseListener(this);

        ptStardew = new EtiquetaTextoPerfil();
        ptStardew.setText("<html><body> <b>Stardew Valley</b> <br> Horas Jugadas: 0.0 Horas</body> </html>");

        ptDanganronpa = new EtiquetaTextoPerfil();
        ptDanganronpa.setText("<html><body> <b>Danganropa: Happy Havoc Trigger</b> <br> Horas Jugadas: 0.0 Horas</body> </html>");

        ptTurnipBoy = new EtiquetaTextoPerfil();
        ptTurnipBoy.setText("<html><body> <b>Turnip Boy Commits Tax Evasion</b> <br> Horas Jugadas: 0.0 Horas</body> </html>");

        ptNier = new EtiquetaTextoPerfil();
        ptNier.setText("<html><body> <b>Nier Automata</b> <br> Horas Jugadas: 0.0 Horas</body> </html>");

        ptOmori = new EtiquetaTextoPerfil();
        ptOmori.setText("<html><body> <b>Omori</b> <br> Horas Jugadas: 0.0 Horas</body> </html>");

        ptUno = new EtiquetaTextoPerfil();
        ptUno.setText("<html><body> <b>Uno</b> <br> Horas Jugadas: 0.0 Horas</body> </html>");

        cStardew = new BotonComprar();
        cStardew.setText("$149.99");
        cStardew.addActionListener(this);
        cDanganronpa = new BotonComprar();
        cDanganronpa.setText("$179.99");
        cDanganronpa.addActionListener(this);
        cTurnipBoy = new BotonComprar();
        cTurnipBoy.setText("$154.99");
        cTurnipBoy.addActionListener(this);
        cNier = new BotonComprar();
        cNier.setText("$665.00");
        cNier.addActionListener(this);
        cOmori = new BotonComprar();
        cOmori.setText("$185.99");
        cOmori.addActionListener(this);
        cUno = new BotonComprar();
        cUno.setText("$199.00");
        cUno.addActionListener(this);

        tienda.add(danganronpa);
        tienda.add(tDanganronpa);
        tienda.add(cDanganronpa);
        tienda.add(nier);
        tienda.add(tNier);
        tienda.add(cNier);
        tienda.add(omori);
        tienda.add(tOmori);
        tienda.add(cOmori);
        tienda.add(stardewValley);
        tienda.add(tStardew);
        tienda.add(cStardew);
        tienda.add(turnipBoy);
        tienda.add(tTurnipBoy);
        tienda.add(cTurnipBoy);
        tienda.add(uno);
        tienda.add(tUno);
        tienda.add(cUno);

        //Panel Perfil
        ImageIcon foto = new ImageIcon("C:\\Users\\valla\\OneDrive\\Documentos\\NetBeansProjects\\"
                + "Proyecto\\src\\Proyecto\\ImagenesJuegos\\foto.png");
        foto = new ImageIcon(foto.getImage().getScaledInstance(175, 175, java.awt.Image.SCALE_SMOOTH));

        fotoUser = new EtiquetaImagenPerfil(foto);
        fotoUser.setPreferredSize(new Dimension(200, 200));
        fotoUser.setHorizontalAlignment(SwingConstants.CENTER);

        subpanelInfo = new Panel();
        subpanelInfo.setPreferredSize(new Dimension(900, 200));
        subpanelInfo.setLayout(new FlowLayout(FlowLayout.LEFT, 0, 25));
        subpanelInfo.setBackground(new Color(26, 41, 56));

        nombreUser = new EtiquetaTextoPerfil();
        nombreUser.setPreferredSize(new Dimension(800, 40));
        nombreUser.setText("Bookun                                                                              Nivel 4");
        nombreUser.setFont(new Font("Calibri", Font.BOLD, 30));

        descUser = new EtiquetaTextoPerfil();
        descUser.setPreferredSize(new Dimension(600, 40));
        descUser.setText("<html><body> La esperanza es lo que nos hace mas fuerte, es la razon por la que estamos aqui."
                + "<br>Es con lo que luchamos cuando todo lo demas esta perdido");
        descUser.setFont(new Font("Calibri", Font.PLAIN, 15));

        ImageIcon insig = new ImageIcon("C:\\Users\\valla\\OneDrive\\Documentos\\"
                + "NetBeansProjects\\Proyecto\\src\\Proyecto\\ImagenesJuegos\\insignia.png");
        insig = new ImageIcon(insig.getImage().getScaledInstance(50, 50, java.awt.Image.SCALE_SMOOTH));

        insignia = new EtiquetaTextoPerfil();
        insignia.setPreferredSize(new Dimension(300, 80));
        insignia.setIcon(insig);
        insignia.setText("Apilador Perspicaz");
        insignia.setBackground(new Color(23, 23, 32));

        subpanelInfo.add(nombreUser);
        subpanelInfo.add(descUser);
        subpanelInfo.add(insignia);

        subpanelPerfil = new Panel();
        subpanelPerfil.setPreferredSize(new Dimension(750, 600));
        subpanelPerfil.setLayout(new FlowLayout(FlowLayout.CENTER, 0, 5));

        perfil.add(fotoUser);
        perfil.add(subpanelInfo);
        perfil.add(subpanelPerfil);

        agregarJuegos();

        scrollTienda = new ScrollPane(tienda);
        scrollPerfil = new ScrollPane(perfil);

        tabulador.add("Tienda", scrollTienda);
        tabulador.add("Perfil", scrollPerfil);

        this.add(tabulador);

        this.setBackground(new Color(27, 44, 67));
        this.setIconImage(imgL);
        this.setSize(1200, 600);
        this.setLocationRelativeTo(this);
        this.setResizable(false);
        this.setVisible(true);
        this.setTitle("Stean");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    public static void main(String[] args) {
        new Proyecto();
    }

    public void agregarJuegos() {
        for (int i = 0; i < biblioteca.length; i++) {
            String ruta = "C:\\Users\\valla\\OneDrive\\Documentos\\"
                    + "NetBeansProjects\\Proyecto\\src\\Proyecto\\Juegos\\" + biblioteca[i] + ".txt";
            File buscar = new File(ruta);
            if (buscar.exists()) {
                switch (biblioteca[i]) {
                    case "Danganronpa":
                        subpanelPerfil.add(pDanganronpa);
                        subpanelPerfil.add(ptDanganronpa);
                        break;
                    case "Nier":
                        subpanelPerfil.add(pNier);
                        subpanelPerfil.add(ptNier);
                        break;
                    case "Omori":
                        subpanelPerfil.add(pOmori);
                        subpanelPerfil.add(ptOmori);
                        break;
                    case "Stardew":
                        subpanelPerfil.add(pStardewValley);
                        subpanelPerfil.add(ptStardew);
                        break;
                    case "TurnipBoy":
                        subpanelPerfil.add(pTurnipBoy);
                        subpanelPerfil.add(ptTurnipBoy);
                        break;
                    case "Uno":
                        subpanelPerfil.add(pUno);
                        subpanelPerfil.add(ptUno);
                        break;
                }
            }
        }
    }

    public void comprarJuego(String nombreA, String nombreJ, String descJuego) {
        try {
            String ruta = "C:\\Users\\valla\\OneDrive\\Documentos\\"
                    + "NetBeansProjects\\Proyecto\\src\\Proyecto\\Juegos\\" + nombreA + ".txt";
            System.out.println(ruta);
            File juego = new File(ruta);
            String contenido = nombreJ + "\nDescripción: \n" + descJuego;
            if (!juego.exists()) {
                juego.createNewFile();
                agregarJuegos();
                JOptionPane.showMessageDialog(null, "Juego añadido a la biblioteca", "Compra Realizada", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(null, "Ya tienes este juego", "Mensaje", JOptionPane.INFORMATION_MESSAGE);
                return;
            }
            BufferedWriter bw = new BufferedWriter(new FileWriter(juego));
            bw.write(contenido);
            bw.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void mouseClicked(MouseEvent e) {
    }

    @Override
    public void mousePressed(MouseEvent e) {
    }

    @Override
    public void mouseReleased(MouseEvent e) {
    }

    @Override
    public void mouseEntered(MouseEvent e) {
        if (e.getSource() == tDanganronpa) {
            tDanganronpa.setBackground(new Color(164, 201, 222));
            tDanganronpa.setForeground(new Color(16, 22, 133));
        }
        if (e.getSource() == tNier) {
            tNier.setBackground(new Color(164, 201, 222));
            tNier.setForeground(new Color(16, 22, 133));
        }
        if (e.getSource() == tOmori) {
            tOmori.setBackground(new Color(164, 201, 222));
            tOmori.setForeground(new Color(16, 22, 133));
        }
        if (e.getSource() == tStardew) {
            tStardew.setBackground(new Color(164, 201, 222));
            tStardew.setForeground(new Color(16, 22, 133));
        }
        if (e.getSource() == tTurnipBoy) {
            tTurnipBoy.setBackground(new Color(164, 201, 222));
            tTurnipBoy.setForeground(new Color(16, 22, 133));
        }
        if (e.getSource() == tUno) {
            tUno.setBackground(new Color(164, 201, 222));
            tUno.setForeground(new Color(16, 22, 133));
        }
    }

    @Override
    public void mouseExited(MouseEvent e) {
        if (e.getSource() == tDanganronpa) {
            tDanganronpa.setBackground(new Color(26, 41, 56));
            tDanganronpa.setForeground(new Color(255, 255, 241));
        }
        if (e.getSource() == tNier) {
            tNier.setBackground(new Color(26, 41, 56));
            tNier.setForeground(new Color(255, 255, 241));
        }
        if (e.getSource() == tOmori) {
            tOmori.setBackground(new Color(26, 41, 56));
            tOmori.setForeground(new Color(255, 255, 241));
        }
        if (e.getSource() == tStardew) {
            tStardew.setBackground(new Color(26, 41, 56));
            tStardew.setForeground(new Color(255, 255, 241));
        }
        if (e.getSource() == tTurnipBoy) {
            tTurnipBoy.setBackground(new Color(26, 41, 56));
            tTurnipBoy.setForeground(new Color(255, 255, 241));
        }
        if (e.getSource() == tUno) {
            tUno.setBackground(new Color(26, 41, 56));
            tUno.setForeground(new Color(255, 255, 241));
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String desc;
        if (e.getSource() == cDanganronpa) {
            int opcion = JOptionPane.showConfirmDialog(null, "Desea comprar este juego?",
                    "Confirmar", JOptionPane.YES_NO_CANCEL_OPTION, JOptionPane.INFORMATION_MESSAGE);
            if (opcion == JOptionPane.YES_OPTION) {
                desc = """
                   Investiga asesinatos, busca pistas y  
                   habla con tus compañeros para preparar el juicio donde tendr\u00e1s 
                   conversaciones letales con los sospechosos. Analiza 
                   las declaraciones y contraat\u00e1calos con sus propias 
                   palabras para revelar las mentiras. Solo hay una forma de sobrevivir: aprieta el gatillo.""";
                comprarJuego("Danganronpa", "Danganronpa: Trigger Happy Havoc", desc);
            }
        }
        if (e.getSource() == cTurnipBoy) {
            int opcion = JOptionPane.showConfirmDialog(null, "Desea comprar este juego?",
                    "Confirmar", JOptionPane.YES_NO_CANCEL_OPTION, JOptionPane.INFORMATION_MESSAGE);
            if (opcion == JOptionPane.YES_OPTION) {
                desc = """
                   Juega como un nabo adorable pero alborotador. 
                   \u00a1Evita pagar los impuestos, resuelve acertijos y pelea 
                   contra bestias enormes para derrocar al corrupto 
                   gobierno vegetal!""";
                comprarJuego("TurnipBoy", "Turnip Boy Commits Tax Evasion", desc);
            }
        }
        if (e.getSource() == cNier) {
            int opcion = JOptionPane.showConfirmDialog(null, "Desea comprar este juego?",
                    "Confirmar", JOptionPane.YES_NO_CANCEL_OPTION, JOptionPane.INFORMATION_MESSAGE);
            if (opcion == JOptionPane.YES_OPTION) {
                desc = """
                   NieR: Automata cuenta la historia de los androides 2B, 9S y A2 y
                   su batalla para recuperar el motor
                   distopía invadida por poderosas máquinas.""";
                comprarJuego("Nier", "Nier Automata", desc);
            }

        }
        if (e.getSource() == cOmori) {
            int opcion = JOptionPane.showConfirmDialog(null, "Desea comprar este juego?",
                    "Confirmar", JOptionPane.YES_NO_CANCEL_OPTION, JOptionPane.INFORMATION_MESSAGE);
            if (opcion == JOptionPane.YES_OPTION) {
                desc = """
                   Explora un mundo extraño lleno de coloridos amigos y
                   enemigos. Cuando llegue el momento, el camino que has elegido
                   determinará tu destino... Y quizás el destino de
                   otros también.""";
                comprarJuego("Omori", "Omori", desc);
            }

        }
        if (e.getSource() == cStardew) {
            int opcion = JOptionPane.showConfirmDialog(null, "Desea comprar este juego?",
                    "Confirmar", JOptionPane.YES_NO_CANCEL_OPTION, JOptionPane.INFORMATION_MESSAGE);
            if (opcion == JOptionPane.YES_OPTION) {
                desc = """
                   Has heredado la antigua parcela agrícola de tu abuelo
                   en Stardew Valley armado con herramientas de segunda mano y unas
                   pocas monedas, te dispones a comenzar una nueva vida. Poder
                   aprender a vivir de la tierra y convertir estos
                   campos cubiertos de maleza en un hogar próspero?""";
                comprarJuego("Stardew", "Stardew Valley", desc);
            }
            
        }
        if (e.getSource() == cUno) {
            int opcion = JOptionPane.showConfirmDialog(null, "Desea comprar este juego?",
                    "Confirmar", JOptionPane.YES_NO_CANCEL_OPTION, JOptionPane.INFORMATION_MESSAGE);
            if (opcion == JOptionPane.YES_OPTION) {
                desc = """
                   ¡UNO regresa con nuevas características emocionantes!
                   Combina cartas por color o valor y juega cartas de acción
                   para cambiar las cosas. Carrera contra otros para vaciar
                   tu mano antes que los demás en el juego clásico o
                   personaliza tu experiencia con las reglas de la casa.""";
                comprarJuego("Uno", "Uno", desc);
            }
            
        }

    }

}
